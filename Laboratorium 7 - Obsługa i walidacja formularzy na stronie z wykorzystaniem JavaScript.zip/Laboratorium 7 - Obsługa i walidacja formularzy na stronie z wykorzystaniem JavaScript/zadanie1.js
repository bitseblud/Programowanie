function podzielLiczby(){

    const wynikElement = document.getElementById('wynik')

    wynikElement.innerHTML = '';
    wynikElement.classList.remove('error');
    wynikElement.style.color = '';

    try{
        const liczba1 = document.getElementById('liczba1').value
        const liczba2 = document.getElementById('liczba2').value

        if(liczba1===''||liczba2===''){
            throw new Error("Prosze wypełnić oba pola");
        }

        if (isNaN(liczba1)||isNaN(liczba2)){
            throw new Error("Prosze podać liczby");
        }

        if (liczba2==0){
            throw new Error("Nie można dzielić przez zero!");
        }

        const wynik = liczba1/liczba2;
        wynikElement.style.color='green'
        wynikElement.innerHTML= 'Wynik:'+ wynik

        } catch (error) {
                wynikElement.classList.add('error');
                wynikElement.innerHTML = error.message;
        }
    }
    

