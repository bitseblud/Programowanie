document.getElementById('registrationForm').addEventListener('submit', function(event) {
            event.preventDefault();
            
    let errors = []

    const username=document.getElementById('username').value.trim();
    const email=document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    const birthdate=document.getElementById('date').value;
    const sex=document.getElementById('sex').value;
    const confirm1=document.getElementById('confirm1').checked;
    const password2=document.getElementById('password2').value;
    const version = document.querySelector('input[name="version"]:checked');
    const versioninput = version ? version.value : null;

    // 1. Czy w nazwie użytkownika są tylko znaki alfanumeryczne
    const alfanumRegex = /^[a-zA-Z0-9]+$/;
        if (username && !alfanumRegex.test(username)) {
            errors.push("Nazwa użytkownika może zawierać tylko litery i cyfry (bez spacji i znaków specjalnych).");
        }

    // 2. Czy wszystkie pola są wypełnione
    if(!username||!email||!password||!password2||!birthdate||!sex||!confirm1||!version)
        errors.push('Wszystkie pola muszą zostać wypełnione, w tym akceptacja regulaminu i wybór wersji.')

    // 3. Walidacja hasła
    if(password!==password2){
        errors.push("Podane hasła nie są identyczne.")
    }
    // 4. Walidacja adresu e-mail
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (email && !emailRegex.test(email)) {
                errors.push("Podany adres e-mail jest niepoprawny.");
            }

    // 5. Czy użytkownik jest pełnoletni
    if (birthdate){
        const birthDateObj = new Date(birthdate);
        const today=new Date();
        let age = today.getFullYear() - birthDateObj.getFullYear();
        const m = today.getMonth() - birthDateObj.getMonth()
        if (m < 0 || (m === 0 && today.getDate() < birthDateObj.getDate())) {
                    age--;
        }
        if (age < 18) {
            errors.push("Musisz być osobą pełnoletnią (ukończone 18 lat), aby się zarejestrować.");    
        }
    }

    let successBox = document.getElementById('successBox')
    let errorBox = document.getElementById('ErrorBox')
     if (errors.length > 0) {
            
                successBox.style.display = 'none';
                errorBox.innerHTML = "Wystąpiły błędy w formularzu:<br><ul><li>" + errors.join("</li><li>") + "</li></ul>";
            } else {
    errorBox.innerHTML = "";
    const [rok, miesiac, dzien] = birthdate.split('-');
    const sformatowanaData = `${dzien}.${miesiac}.${rok}`;

    const zagwiazdkowaneHaslo = '*'.repeat(password.length);

    document.getElementById('out_username').textContent = username;
    document.getElementById('out_password').textContent = zagwiazdkowaneHaslo;
    document.getElementById('out_email').textContent = email;
    document.getElementById('out_birthdate').textContent = sformatowanaData;
    document.getElementById('out_gender').textContent = sex;
    document.getElementById('out_version').textContent = version;

    successBox.style.display ='block'

}
document.getElementById('resetbutton').addEventListener('click', function() {
            document.getElementById('errorBox').innerHTML = "";
            document.getElementById('successBox').style.display = 'inline-block';
        });     
})
