let start = document.getElementById("start");
let stop = document.getElementById("stop");
let reset = document.getElementById("reset");
let zapisz = document.getElementById("zapisz");
let stanStopera = document.getElementById("stan_stopera");
let zapisaneCzasy = document.getElementById("zapisane_czasy");

let totalSeconds = 0; 

let timerInterval;
function startTimer() {
    timerInterval = setInterval(function() {
        totalSeconds++;
        godziny=Math.floor(totalSeconds / 3600);
        minuty=Math.floor((totalSeconds % 3600) / 60);
        sekundy=totalSeconds % 60;
        document.getElementById('sekundy').innerText = sekundy.toString().padStart(2, '0');
        document.getElementById('minuty').innerText = minuty.toString().padStart(2, '0');
        document.getElementById('godziny').innerText = godziny.toString().padStart(2, '0');
        }, 1000); 
}

start.addEventListener("click", () => {
    startTimer();
    stop.style.display = "inline-block";
    document.getElementById('stan_stopera').innerText = "Obliczanie trwa";
    reset.style.display = "None";
    start.style.display = "None";
});
reset.addEventListener("click", () => {
    clearInterval(timerInterval);
    totalSeconds = 0;
    document.getElementById('sekundy').innerText = '00';
    document.getElementById('minuty').innerText = '00';
    document.getElementById('godziny').innerText = '00';
    zapisaneCzasy.innerHTML = '';
    stop.style.display = "None";
    reset.style.display = "None";
    start.style.display = "inline-block";
    document.getElementById('stan_stopera').innerText = " ";

});
stop.addEventListener("click", () => {
    clearInterval(timerInterval);
    stop.style.display = "None";
    document.getElementById('stan_stopera').innerText = "Obliczanie zatrzymane";
    reset.style.display = "inline-block";
    start.style.display = "inline-block";
});
zapisz.addEventListener("click", () => {
    let zapisanyCzas = document.createElement("li");
    let s = document.getElementById('sekundy').innerText;
    let m = document.getElementById('minuty').innerText;
    let g = document.getElementById('godziny').innerText;
    zapisanyCzas.innerText=`${g}:${m}:${s}`;
    zapisaneCzasy.appendChild(zapisanyCzas);
});
    if (totalSeconds === 0) {
        reset.style.display = "none";
    }
