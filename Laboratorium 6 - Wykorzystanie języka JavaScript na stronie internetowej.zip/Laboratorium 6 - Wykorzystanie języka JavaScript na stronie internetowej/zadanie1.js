
const menulink = document.getElementById('menu_link');
const linklist = document.getElementById('link_list');
const menuContainer = document.getElementById('menu');

menulink.addEventListener('mouseenter', () => {
    linklist.style.visibility = 'visible';
});
menuContainer.addEventListener('mouseleave', () => {
    linklist.style.visibility = 'hidden';
});
