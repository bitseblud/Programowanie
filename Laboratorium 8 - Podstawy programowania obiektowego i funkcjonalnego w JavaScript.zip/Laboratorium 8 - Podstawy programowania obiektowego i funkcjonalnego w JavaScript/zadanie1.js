const form = document.getElementById('myForm');

form.addEventListener('submit', function (event) {
  console.log('Скрипт успешно подключен!');
  // Отменяем стандартную перезагрузку страницы при отправке
  event.preventDefault();

  // Создаем объект и сразу записываем в него значения из полей
  const userObject = {
    firstname: document.getElementById('firstname').value,
    lastname: document.getElementById('lastname').value,
    age: document.getElementById('age').value
  };

  console.log(userObject);
  console.log(userObject.firstname, userObject.lastname, userObject.age)
  const jsonsting = JSON.stringify(userObject)
  console.log(jsonsting)
});